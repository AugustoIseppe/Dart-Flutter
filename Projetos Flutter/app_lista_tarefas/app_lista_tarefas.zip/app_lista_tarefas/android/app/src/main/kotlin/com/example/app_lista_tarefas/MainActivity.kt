package com.example.app_lista_tarefas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
