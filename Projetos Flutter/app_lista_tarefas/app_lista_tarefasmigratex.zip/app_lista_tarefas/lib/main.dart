import 'package:app_lista_tarefas/pages/home.dart';
import 'package:flutter/material.dart';

void main() => runApp(const MaterialApp(
  home: Home(),
  debugShowCheckedModeBanner: false
    )
  );

